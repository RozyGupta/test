const people=require("./people")

module.exports = {
	people: people,
  };