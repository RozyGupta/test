


const uuid = require("node-uuid");
const axios = require('axios');

async function getPeople() {
    
  const { data } = await axios.get('https://gist.githubusercontent.com/robherley/5112d73f5c69a632ef3ae9b7b3073f78/raw/24a7e1453e65a26a8aa12cd0fb266ed9679816aa/people.json')

  if(typeof data != "object")
  	throw "The given data is not of proper type and undefined.";

  if(data.length == 0)
  	throw "The people.json file is empty.";
  return data 
}

async function getPersonById(id) {

const getPeople = await getPeople();
	
	return getPeople().then(peopleCollection => {
		return peopleCollection.find({id: id }).then(person => {
			if(!post) throw "Person not found";
		return person;
		});
	});
		
}

module.exports = {
	getPeople,
	getPersonById
}