const express = require("express");
const router = express.Router();
const data = require("../data");
const detailsData = data.details;


router.get("/", (req, res) => {
	res.render('welcome/inde');
});

router.get("/:id", (req, res) => {
	detailsData
		.getUserById(req.params.id)
			.then(person => {
				res.json(person);
			})
			.catch((e) => {
				res.status(404).json({error: e});
	});
});

module.exports = router;