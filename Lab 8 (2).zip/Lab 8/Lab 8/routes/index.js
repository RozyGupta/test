const searchRoutes = require("./search");
//const detailsRoutes = require("./details");
//const errorRoutes = require("./error");
const path = require("path");

const constructorMethod = app => {
    
	app.use("/", searchRoutes);
	//app.use("/details", detailsRoutes);
	//app.use("/error", errorRoutes);

	app.use("*", (req, res) => {
		res.redirect("/search")
	});
};

module.exports = constructorMethod;
