const express = require("express");
const router = express.Router();
const data = require("../data");
const errorData = data.error;

router.get("/", async(req, res) => {
	res.render('welcome/error');
});

module.exports = router;