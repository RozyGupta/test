const express = require("express");
const router = express.Router();
const data = require("../data");
const peopleData = data.people;


router.get("/", async(req, res) => {
	res.render('welcome/index');
});

router.post("/search", async(req, res) => {
    let searchInput = req.body;
    console.log(searchInput);
        
	if(!searchInput.personName) {
		res.status(400).send({error: "Please provide data!"});
		return;
	}

	try{
		const newSearch = await peopleData.getUserByUsername(searchInput.personName);
		console.log(newSearch);
		res.render('welcome/search', { search_results: newSearch });
	}

	catch(e) {
		res.status(500).json({error: "Person not found!"});
	}
});

module.exports = router;
